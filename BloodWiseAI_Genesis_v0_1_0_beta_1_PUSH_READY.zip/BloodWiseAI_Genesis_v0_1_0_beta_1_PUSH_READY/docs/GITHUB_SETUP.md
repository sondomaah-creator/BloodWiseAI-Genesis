# GitHub setup

## Create the repository

```bash
git init
git branch -M main
git add .
git commit -m "chore: initialize BloodWise Genesis alpha 9"
git remote add origin <YOUR_PRIVATE_REPOSITORY_URL>
git push -u origin main
```

## Development branch

```bash
git checkout -b develop
git push -u origin develop
```

## Build an APK in GitHub

1. Push the repository to GitHub.
2. Open **Actions**.
3. Run **Build Android Release APK**, or push a tag:
   ```bash
   git tag v0.1.0-beta.1-candidate
   git push origin v0.1.0-beta.1-candidate
   ```
4. Download the APK artifact from the completed workflow.

The current release workflow creates an unsigned release APK for internal
testing. Production signing requires a protected keystore and GitHub secrets.
