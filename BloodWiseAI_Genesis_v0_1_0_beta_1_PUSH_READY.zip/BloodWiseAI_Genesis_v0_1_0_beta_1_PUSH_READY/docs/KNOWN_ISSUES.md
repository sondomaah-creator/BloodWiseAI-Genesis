# Known Issues — Beta 1 Candidate

1. Native Flutter compilation has not been executed in the current generation
   environment because the Flutter SDK is unavailable.
2. Text-to-speech voice availability depends on the operating system.
3. Profile storage uses SharedPreferences for the MVP. A structured database is
   recommended before adding history or multiple profiles.
4. The app currently provides English interface text. Voice locale selection
   supports English, French, and Spanish where the device has matching voices.
5. The release APK workflow is not production-signed.
