# Debugging

## Start button

`SplashScreen._start()` is the only startup command. It:

1. Ignores repeated taps while busy.
2. Reads `profileProvider.future`.
3. Routes to `/profile` when no profile exists.
4. Routes to `/dashboard` when a profile exists.

## Reset

Use **RESET PROFILE** on the dashboard. This clears the local profile and returns to onboarding.

## Common commands

```bash
flutter clean
flutter pub get
dart format .
flutter analyze
flutter test
flutter run -v
```

## TTS

Text-to-speech depends on voices installed by the operating system. Unsupported locales may fall back to a default device voice.
