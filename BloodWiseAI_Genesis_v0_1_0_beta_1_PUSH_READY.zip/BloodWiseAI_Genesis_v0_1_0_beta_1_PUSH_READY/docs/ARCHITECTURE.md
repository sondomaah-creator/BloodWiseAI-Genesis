# Architecture

The Alpha uses a deliberately small structure:

- **App** — theme and GoRouter.
- **Models** — immutable `UserProfile`.
- **Services** — local persistence and report generation.
- **Providers** — Riverpod state and dependency wiring.
- **Features** — splash, onboarding, dashboard, report, About.

The profile is stored as one JSON record. This avoids generated database code while preserving a clear migration path to Drift when multiple records or historical tracking are introduced.
