# Beta 1 Release Checklist

## Source verification

- [ ] `flutter create . --platforms=android,ios,web`
- [ ] `flutter pub get`
- [ ] `dart format .`
- [ ] `flutter analyze`
- [ ] `flutter test`
- [ ] `flutter build apk --debug`

## Functional verification

- [ ] Logo is visible
- [ ] Exactly one Start Application button is shown
- [ ] First launch opens Smart Profile
- [ ] Profile saves successfully
- [ ] Dashboard displays saved values
- [ ] Report opens
- [ ] Text-to-speech starts and stops
- [ ] Restart routes a returning user to Dashboard
- [ ] Reset Profile returns to onboarding

## Device verification

- [ ] Android phone
- [ ] Android tablet
- [ ] Web/PWA
- [ ] iPhone simulator or device

## Release documentation

- [ ] README updated
- [ ] CHANGELOG updated
- [ ] PRIVACY reviewed
- [ ] Known issues documented
- [ ] APK checksum recorded
