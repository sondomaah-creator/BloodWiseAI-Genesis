# Privacy Policy — Development Candidate

BloodWise+ AI Genesis is designed as a local-first educational application.

## Data stored

The MVP stores the profile information entered by the user on the user's device.
This can include name, date of birth, blood group, Rh factor, height, weight,
activity level, language preference, and donor preference.

## Data transmission

The current MVP source does not include cloud synchronization, analytics,
advertising, or third-party account login.

## Purpose

The stored information is used to personalize general educational content,
calculate age and BMI, and create an educational wellness report.

## User control

The user can clear the stored profile from the Dashboard using **RESET PROFILE**.

## Medical disclaimer

The application provides general education. It does not provide diagnosis,
treatment, prescriptions, emergency services, or a substitute for a qualified
healthcare professional.

## Project attribution

- Founder: Papany Podol
- Author (Legal Name): Jean Bertin Tonje – Mbombog Pharaoh Tonje
- Copyright © 2026. All Rights Reserved.
