## Summary

## Related issue

## Verification

- [ ] `dart format .`
- [ ] `flutter analyze`
- [ ] `flutter test`
- [ ] Manual startup flow tested
- [ ] Documentation updated
- [ ] No personal health data or secrets included

## Screenshots

## Known limitations
