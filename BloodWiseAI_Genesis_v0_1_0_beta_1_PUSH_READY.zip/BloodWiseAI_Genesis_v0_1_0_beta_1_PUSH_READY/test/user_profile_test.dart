/// ------------------------------------------------------------
/// BloodWise+ AI Genesis
/// Founder: Papany Podol
/// Author (Legal Name): Jean Bertin Tonje – Mbombog Pharaoh Tonje
/// Copyright © 2026. All Rights Reserved.
/// Version: 0.1.0-beta.1-candidate
/// ------------------------------------------------------------


import 'package:bloodwise_ai_genesis/core/models/user_profile.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('calculates age around birthday correctly', () {
    final profile = UserProfile(
      fullName: 'Test User',
      dateOfBirth: DateTime(2000, 7, 10),
      bloodType: 'O',
      rhFactor: 'Positive',
      heightCm: 180,
      weightKg: 75,
      sex: 'Prefer not to say',
      activityLevel: 'Moderate',
      preferredLanguage: 'English',
      bloodDonor: false,
    );

    expect(profile.ageOn(DateTime(2026, 7, 9)), 25);
    expect(profile.ageOn(DateTime(2026, 7, 10)), 26);
  });

  test('round trips JSON storage', () {
    final original = UserProfile(
      fullName: 'Jean Test',
      dateOfBirth: DateTime(1980, 1, 2),
      bloodType: 'AB',
      rhFactor: 'Negative',
      heightCm: 170,
      weightKg: 70,
      sex: 'Male',
      activityLevel: 'Active',
      preferredLanguage: 'French',
      bloodDonor: true,
    );

    final decoded = UserProfile.decode(original.encode());

    expect(decoded.fullName, original.fullName);
    expect(decoded.bloodDisplay, 'AB-');
    expect(decoded.bloodDonor, isTrue);
  });
}
