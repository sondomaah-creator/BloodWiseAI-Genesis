/// ------------------------------------------------------------
/// BloodWise+ AI Genesis
/// Founder: Papany Podol
/// Author (Legal Name): Jean Bertin Tonje – Mbombog Pharaoh Tonje
/// Copyright © 2026. All Rights Reserved.
/// Version: 0.1.0-beta.1-candidate
/// ------------------------------------------------------------


import 'package:bloodwise_ai_genesis/features/onboarding/profile_validator.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('validates name', () {
    expect(ProfileValidator.name(''), isNotNull);
    expect(ProfileValidator.name('J'), isNotNull);
    expect(ProfileValidator.name('Jean'), isNull);
  });

  test('validates physical ranges', () {
    expect(ProfileValidator.height('180'), isNull);
    expect(ProfileValidator.height('400'), isNotNull);
    expect(ProfileValidator.weight('75'), isNull);
    expect(ProfileValidator.weight('0'), isNotNull);
  });
}
