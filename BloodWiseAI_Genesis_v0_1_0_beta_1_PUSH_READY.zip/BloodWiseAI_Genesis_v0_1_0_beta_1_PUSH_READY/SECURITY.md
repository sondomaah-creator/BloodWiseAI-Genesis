# Security Policy

## Supported release

The current development line is `0.1.x`.

## Reporting a vulnerability

Do not post sensitive vulnerability details in a public issue. Send a private
report to the project owner and include:

- affected version
- platform and device
- reproduction steps
- expected and actual behavior
- screenshots or logs with personal information removed

## Health and personal data

The MVP stores one profile locally. Do not commit real health data, signing
keys, credentials, or exported user records to source control.
