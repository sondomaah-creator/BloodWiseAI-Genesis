/// ------------------------------------------------------------
/// BloodWise+ AI Genesis
/// Founder: Papany Podol
/// Author (Legal Name): Jean Bertin Tonje – Mbombog Pharaoh Tonje
/// Copyright © 2026. All Rights Reserved.
/// Version: 0.1.0-beta.1-candidate
/// ------------------------------------------------------------


import 'package:shared_preferences/shared_preferences.dart';
import '../models/user_profile.dart';

class ProfileStorage {
  static const _profileKey = 'bloodwise_user_profile_v1';

  Future<UserProfile?> load() async {
    final preferences = await SharedPreferences.getInstance();
    final encoded = preferences.getString(_profileKey);
    if (encoded == null || encoded.isEmpty) return null;
    try {
      return UserProfile.decode(encoded);
    } on FormatException {
      await preferences.remove(_profileKey);
      return null;
    } on TypeError {
      await preferences.remove(_profileKey);
      return null;
    }
  }

  Future<void> save(UserProfile profile) async {
    final preferences = await SharedPreferences.getInstance();
    final stored = await preferences.setString(_profileKey, profile.encode());
    if (!stored) {
      throw StateError('The profile could not be stored on this device.');
    }
  }

  Future<void> clear() async {
    final preferences = await SharedPreferences.getInstance();
    await preferences.remove(_profileKey);
  }
}
