/// ------------------------------------------------------------
/// BloodWise+ AI Genesis
/// Founder: Papany Podol
/// Author (Legal Name): Jean Bertin Tonje – Mbombog Pharaoh Tonje
/// Copyright © 2026. All Rights Reserved.
/// Version: 0.1.0-beta.1-candidate
/// ------------------------------------------------------------


import '../models/user_profile.dart';

class ReportService {
  const ReportService();

  String build(UserProfile profile) {
    final rhText = profile.rhFactor == 'Positive'
        ? 'Rh positive'
        : 'Rh negative';

    return '''BloodWise+ AI Genesis — Educational Wellness Report

Name: ${profile.fullName}
Age: ${profile.age}
Blood group: ${profile.bloodDisplay} ($rhText)
BMI: ${profile.bmi.toStringAsFixed(1)}
Activity level: ${profile.activityLevel}

Blood-group education
Your ABO and Rh type are medically important for transfusion matching and pregnancy care. Blood type alone does not determine which foods are healthiest for you.

Nutrition
Choose a varied diet built around vegetables, fruit, whole grains, legumes, lean protein or suitable alternatives, and unsaturated fats. Adjust portions and nutrient needs for age, activity, allergies, pregnancy, and clinician advice.

Hygiene
Wash hands with soap at key times, maintain oral hygiene, bathe as needed, keep food-preparation surfaces clean, and store foods at safe temperatures.

Rh information
Rh-negative people may need special medical management during pregnancy when fetal Rh status differs. Discuss pregnancy and transfusion questions with a qualified clinician.

Important
This application provides general education. It does not diagnose disease, prescribe treatment, or replace a healthcare professional.''';
  }
}
