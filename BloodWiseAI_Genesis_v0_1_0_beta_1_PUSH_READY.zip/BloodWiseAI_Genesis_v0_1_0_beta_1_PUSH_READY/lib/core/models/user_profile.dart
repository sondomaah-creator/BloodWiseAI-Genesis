/// ------------------------------------------------------------
/// BloodWise+ AI Genesis
/// Founder: Papany Podol
/// Author (Legal Name): Jean Bertin Tonje – Mbombog Pharaoh Tonje
/// Copyright © 2026. All Rights Reserved.
/// Version: 0.1.0-beta.1-candidate
/// ------------------------------------------------------------


import 'dart:convert';
import 'package:flutter/foundation.dart';

@immutable
class UserProfile {
  const UserProfile({
    required this.fullName,
    required this.dateOfBirth,
    required this.bloodType,
    required this.rhFactor,
    required this.heightCm,
    required this.weightKg,
    required this.sex,
    required this.activityLevel,
    required this.preferredLanguage,
    required this.bloodDonor,
  });

  final String fullName;
  final DateTime dateOfBirth;
  final String bloodType;
  final String rhFactor;
  final double heightCm;
  final double weightKg;
  final String sex;
  final String activityLevel;
  final String preferredLanguage;
  final bool bloodDonor;

  int ageOn(DateTime today) {
    var years = today.year - dateOfBirth.year;
    if (today.month < dateOfBirth.month ||
        (today.month == dateOfBirth.month && today.day < dateOfBirth.day)) {
      years--;
    }
    return years;
  }

  int get age => ageOn(DateTime.now());

  double get bmi {
    final metres = heightCm / 100;
    return weightKg / (metres * metres);
  }

  String get bloodDisplay => '$bloodType${rhFactor == 'Positive' ? '+' : '-'}';

  Map<String, Object?> toJson() => {
        'fullName': fullName,
        'dateOfBirth': dateOfBirth.toIso8601String(),
        'bloodType': bloodType,
        'rhFactor': rhFactor,
        'heightCm': heightCm,
        'weightKg': weightKg,
        'sex': sex,
        'activityLevel': activityLevel,
        'preferredLanguage': preferredLanguage,
        'bloodDonor': bloodDonor,
      };

  String encode() => jsonEncode(toJson());

  factory UserProfile.fromJson(Map<String, Object?> json) {
    return UserProfile(
      fullName: json['fullName']! as String,
      dateOfBirth: DateTime.parse(json['dateOfBirth']! as String),
      bloodType: json['bloodType']! as String,
      rhFactor: json['rhFactor']! as String,
      heightCm: (json['heightCm']! as num).toDouble(),
      weightKg: (json['weightKg']! as num).toDouble(),
      sex: json['sex']! as String,
      activityLevel: json['activityLevel']! as String,
      preferredLanguage: json['preferredLanguage']! as String,
      bloodDonor: json['bloodDonor']! as bool,
    );
  }

  factory UserProfile.decode(String source) {
    return UserProfile.fromJson(
      jsonDecode(source) as Map<String, Object?>,
    );
  }
}
