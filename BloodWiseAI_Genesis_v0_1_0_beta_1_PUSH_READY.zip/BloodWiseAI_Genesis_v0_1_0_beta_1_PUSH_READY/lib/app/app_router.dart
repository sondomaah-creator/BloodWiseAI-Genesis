/// ------------------------------------------------------------
/// BloodWise+ AI Genesis
/// Founder: Papany Podol
/// Author (Legal Name): Jean Bertin Tonje – Mbombog Pharaoh Tonje
/// Copyright © 2026. All Rights Reserved.
/// Version: 0.1.0-beta.1-candidate
/// ------------------------------------------------------------


import 'package:go_router/go_router.dart';
import '../features/about/about_screen.dart';
import '../features/dashboard/dashboard_screen.dart';
import '../features/onboarding/smart_profile_screen.dart';
import '../features/report/report_screen.dart';
import '../features/splash/splash_screen.dart';

abstract final class AppRoutes {
  static const splash = '/';
  static const profile = '/profile';
  static const dashboard = '/dashboard';
  static const report = '/report';
  static const about = '/about';
}

final appRouter = GoRouter(
  initialLocation: AppRoutes.splash,
  routes: [
    GoRoute(
      path: AppRoutes.splash,
      builder: (context, state) => const SplashScreen(),
    ),
    GoRoute(
      path: AppRoutes.profile,
      builder: (context, state) => const SmartProfileScreen(),
    ),
    GoRoute(
      path: AppRoutes.dashboard,
      builder: (context, state) => const DashboardScreen(),
    ),
    GoRoute(
      path: AppRoutes.report,
      builder: (context, state) => const ReportScreen(),
    ),
    GoRoute(
      path: AppRoutes.about,
      builder: (context, state) => const AboutScreen(),
    ),
  ],
);
