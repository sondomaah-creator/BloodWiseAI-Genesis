/// ------------------------------------------------------------
/// BloodWise+ AI Genesis
/// Founder: Papany Podol
/// Author (Legal Name): Jean Bertin Tonje – Mbombog Pharaoh Tonje
/// Copyright © 2026. All Rights Reserved.
/// Version: 0.1.0-beta.1-candidate
/// ------------------------------------------------------------


import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../app/app_router.dart';
import '../../core/providers/app_providers.dart';

class SplashScreen extends ConsumerStatefulWidget {
  const SplashScreen({super.key});

  @override
  ConsumerState<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends ConsumerState<SplashScreen> {
  bool _starting = false;

  Future<void> _start() async {
    if (_starting) return;
    setState(() => _starting = true);

    final profile = await ref.read(profileProvider.future);
    if (!mounted) return;

    context.go(profile == null ? AppRoutes.profile : AppRoutes.dashboard);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(28),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 520),
              child: Column(
                children: [
                  Semantics(
                    label: 'Si Ngambi crest',
                    image: true,
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(28),
                      child: Image.asset(
                        'assets/images/si_ngambi_logo.jpeg',
                        height: 330,
                        fit: BoxFit.contain,
                      ),
                    ),
                  ),
                  const SizedBox(height: 26),
                  Text(
                    'BloodWise+ AI',
                    style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                          fontWeight: FontWeight.w800,
                        ),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'Knowledge Empowers Healthier Choices',
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 34),
                  Semantics(
                    button: true,
                    label: 'Start BloodWise application',
                    child: FilledButton.icon(
                      onPressed: _starting ? null : _start,
                      icon: _starting
                          ? const SizedBox.square(
                              dimension: 20,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : const Icon(Icons.play_arrow_rounded),
                      label: Text(
                        _starting ? 'STARTING…' : 'START APPLICATION',
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  const Text('Genesis • v0.1.0-beta.1-candidate'),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
