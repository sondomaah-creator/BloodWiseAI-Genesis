/// ------------------------------------------------------------
/// BloodWise+ AI Genesis
/// Founder: Papany Podol
/// Author (Legal Name): Jean Bertin Tonje – Mbombog Pharaoh Tonje
/// Copyright © 2026. All Rights Reserved.
/// Version: 0.1.0-beta.1-candidate
/// ------------------------------------------------------------


import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../app/app_router.dart';
import '../../core/models/user_profile.dart';
import '../../core/providers/app_providers.dart';
import 'profile_validator.dart';

class SmartProfileScreen extends ConsumerStatefulWidget {
  const SmartProfileScreen({super.key});

  @override
  ConsumerState<SmartProfileScreen> createState() =>
      _SmartProfileScreenState();
}

class _SmartProfileScreenState extends ConsumerState<SmartProfileScreen> {
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _dobManual = TextEditingController();
  final _height = TextEditingController();
  final _weight = TextEditingController();

  DateTime? _dateOfBirth;
  String _bloodType = 'O';
  String _rhFactor = 'Positive';
  String _sex = 'Prefer not to say';
  String _activity = 'Moderate';
  String _language = 'English';
  bool _bloodDonor = false;
  bool _saving = false;

  Future<void> _pickDate() async {
    final now = DateTime.now();
    final selected = await showDatePicker(
      context: context,
      initialDate: _dateOfBirth ?? DateTime(now.year - 30),
      firstDate: DateTime(1900),
      lastDate: now,
      helpText: 'Select date of birth',
    );
    if (selected != null) {
      setState(() {
        _dateOfBirth = selected;
        _dobManual.text =
            '${selected.month.toString().padLeft(2, '0')}/'
            '${selected.day.toString().padLeft(2, '0')}/'
            '${selected.year}';
      });
    }
  }

  DateTime? _parseManualDate(String value) {
    final normalized = value.trim().replaceAll('-', '/');
    final parts = normalized.split('/');
    if (parts.length != 3) return null;

    final first = int.tryParse(parts[0]);
    final second = int.tryParse(parts[1]);
    final year = int.tryParse(parts[2]);
    if (first == null || second == null || year == null) return null;

    final month = first > 12 ? second : first;
    final day = first > 12 ? first : second;
    final date = DateTime(year, month, day);
    if (date.year != year || date.month != month || date.day != day) {
      return null;
    }
    return date;
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;

    final manual = _parseManualDate(_dobManual.text);
    final dob = manual ?? _dateOfBirth;
    if (dob == null || dob.isAfter(DateTime.now())) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Enter or select a valid date of birth.'),
        ),
      );
      return;
    }

    setState(() => _saving = true);

    final profile = UserProfile(
      fullName: _name.text.trim(),
      dateOfBirth: dob,
      bloodType: _bloodType,
      rhFactor: _rhFactor,
      heightCm: double.parse(_height.text),
      weightKg: double.parse(_weight.text),
      sex: _sex,
      activityLevel: _activity,
      preferredLanguage: _language,
      bloodDonor: _bloodDonor,
    );

    await ref.read(profileProvider.notifier).save(profile);
    if (!mounted) return;

    final result = ref.read(profileProvider);
    setState(() => _saving = false);

    result.when(
      data: (_) => context.go(AppRoutes.dashboard),
      loading: () {},
      error: (error, stackTrace) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not save profile: $error')),
        );
      },
    );
  }

  @override
  void dispose() {
    _name.dispose();
    _dobManual.dispose();
    _height.dispose();
    _weight.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    const bloodTypes = ['A', 'B', 'AB', 'O'];
    const rhFactors = ['Positive', 'Negative'];
    const sexes = ['Female', 'Male', 'Intersex', 'Prefer not to say'];
    const activities = ['Sedentary', 'Light', 'Moderate', 'Active', 'Very Active'];
    const languages = ['English', 'French', 'Spanish'];

    return Scaffold(
      appBar: AppBar(title: const Text('Smart Profile')),
      body: SafeArea(
        child: Form(
          key: _formKey,
          child: ListView(
            padding: const EdgeInsets.all(20),
            children: [
              Text(
                'Create your profile',
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                      fontWeight: FontWeight.w800,
                    ),
              ),
              const SizedBox(height: 6),
              const Text('Your information stays on this device in the MVP.'),
              const SizedBox(height: 24),
              TextFormField(
                controller: _name,
                textInputAction: TextInputAction.next,
                validator: ProfileValidator.name,
                decoration: const InputDecoration(
                  labelText: 'Full name',
                  prefixIcon: Icon(Icons.person_outline),
                ),
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _dobManual,
                keyboardType: TextInputType.datetime,
                decoration: InputDecoration(
                  labelText: 'Date of birth',
                  hintText: 'MM/DD/YYYY or DD/MM/YYYY',
                  prefixIcon: const Icon(Icons.cake_outlined),
                  suffixIcon: IconButton(
                    tooltip: 'Open calendar',
                    onPressed: _pickDate,
                    icon: const Icon(Icons.calendar_month),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              DropdownButtonFormField<String>(
                initialValue: _language,
                decoration: const InputDecoration(
                  labelText: 'Language',
                  prefixIcon: Icon(Icons.language),
                ),
                items: languages
                    .map((value) =>
                        DropdownMenuItem(value: value, child: Text(value)))
                    .toList(),
                onChanged: (value) =>
                    setState(() => _language = value ?? _language),
              ),
              const SizedBox(height: 16),
              DropdownButtonFormField<String>(
                initialValue: _sex,
                decoration: const InputDecoration(
                  labelText: 'Sex',
                  prefixIcon: Icon(Icons.badge_outlined),
                ),
                items: sexes
                    .map((value) =>
                        DropdownMenuItem(value: value, child: Text(value)))
                    .toList(),
                onChanged: (value) => setState(() => _sex = value ?? _sex),
              ),
              const SizedBox(height: 22),
              Text('Blood information',
                  style: Theme.of(context).textTheme.titleLarge),
              const SizedBox(height: 12),
              SegmentedButton<String>(
                segments: bloodTypes
                    .map((type) => ButtonSegment(value: type, label: Text(type)))
                    .toList(),
                selected: {_bloodType},
                onSelectionChanged: (selection) {
                  setState(() => _bloodType = selection.first);
                },
              ),
              const SizedBox(height: 14),
              SegmentedButton<String>(
                segments: rhFactors
                    .map((factor) => ButtonSegment(
                          value: factor,
                          label: Text(factor == 'Positive' ? 'Rh +' : 'Rh −'),
                        ))
                    .toList(),
                selected: {_rhFactor},
                onSelectionChanged: (selection) {
                  setState(() => _rhFactor = selection.first);
                },
              ),
              SwitchListTile.adaptive(
                contentPadding: EdgeInsets.zero,
                value: _bloodDonor,
                title: const Text('Blood donor'),
                subtitle: const Text(
                  'Informational only; this does not determine eligibility.',
                ),
                onChanged: (value) => setState(() => _bloodDonor = value),
              ),
              const SizedBox(height: 12),
              Text('Physical profile',
                  style: Theme.of(context).textTheme.titleLarge),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: TextFormField(
                      controller: _height,
                      keyboardType: const TextInputType.numberWithOptions(
                        decimal: true,
                      ),
                      validator: ProfileValidator.height,
                      decoration: const InputDecoration(labelText: 'Height (cm)'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: TextFormField(
                      controller: _weight,
                      keyboardType: const TextInputType.numberWithOptions(
                        decimal: true,
                      ),
                      validator: ProfileValidator.weight,
                      decoration: const InputDecoration(labelText: 'Weight (kg)'),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              DropdownButtonFormField<String>(
                initialValue: _activity,
                decoration: const InputDecoration(
                  labelText: 'Activity level',
                  prefixIcon: Icon(Icons.directions_walk),
                ),
                items: activities
                    .map((value) =>
                        DropdownMenuItem(value: value, child: Text(value)))
                    .toList(),
                onChanged: (value) =>
                    setState(() => _activity = value ?? _activity),
              ),
              const SizedBox(height: 28),
              FilledButton.icon(
                onPressed: _saving ? null : _save,
                icon: _saving
                    ? const SizedBox.square(
                        dimension: 20,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Icon(Icons.check_circle_outline),
                label: Text(_saving ? 'SAVING…' : 'SAVE & CONTINUE'),
              ),
              const SizedBox(height: 12),
              const Text(
                'Educational only. Blood type does not determine an ideal diet.',
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
