/// ------------------------------------------------------------
/// BloodWise+ AI Genesis
/// Founder: Papany Podol
/// Author (Legal Name): Jean Bertin Tonje – Mbombog Pharaoh Tonje
/// Copyright © 2026. All Rights Reserved.
/// Version: 0.1.0-beta.1-candidate
/// ------------------------------------------------------------


class ProfileValidator {
  ProfileValidator._();

  static String? name(String? value) {
    final text = value?.trim() ?? '';
    if (text.isEmpty) return 'Full name is required.';
    if (text.length < 2) return 'Enter at least two characters.';
    return null;
  }

  static String? height(String? value) {
    final number = double.tryParse(value ?? '');
    if (number == null) return 'Enter a numeric height.';
    if (number < 50 || number > 250) {
      return 'Height must be between 50 and 250 cm.';
    }
    return null;
  }

  static String? weight(String? value) {
    final number = double.tryParse(value ?? '');
    if (number == null) return 'Enter a numeric weight.';
    if (number < 10 || number > 350) {
      return 'Weight must be between 10 and 350 kg.';
    }
    return null;
  }
}
