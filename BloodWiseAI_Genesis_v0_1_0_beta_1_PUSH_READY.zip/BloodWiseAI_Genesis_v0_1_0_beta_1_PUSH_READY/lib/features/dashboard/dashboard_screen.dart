/// ------------------------------------------------------------
/// BloodWise+ AI Genesis
/// Founder: Papany Podol
/// Author (Legal Name): Jean Bertin Tonje – Mbombog Pharaoh Tonje
/// Copyright © 2026. All Rights Reserved.
/// Version: 0.1.0-beta.1-candidate
/// ------------------------------------------------------------


import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../app/app_router.dart';
import '../../core/providers/app_providers.dart';

class DashboardScreen extends ConsumerWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final profileValue = ref.watch(profileProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('BloodWise+ AI'),
        actions: [
          IconButton(
            tooltip: 'About',
            onPressed: () => context.push(AppRoutes.about),
            icon: const Icon(Icons.info_outline),
          ),
        ],
      ),
      body: profileValue.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (error, stackTrace) => _ErrorState(
          message: '$error',
          onRetry: () => ref.invalidate(profileProvider),
        ),
        data: (profile) {
          if (profile == null) {
            return _ErrorState(
              message: 'No profile was found.',
              onRetry: () => context.go(AppRoutes.profile),
              actionText: 'CREATE PROFILE',
            );
          }

          return ListView(
            padding: const EdgeInsets.all(20),
            children: [
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Row(
                    children: [
                      const CircleAvatar(
                        radius: 30,
                        child: Icon(Icons.person, size: 34),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text('Welcome'),
                            Text(
                              profile.fullName,
                              style: Theme.of(context)
                                  .textTheme
                                  .headlineSmall
                                  ?.copyWith(fontWeight: FontWeight.w800),
                            ),
                            Text('${profile.age} years • ${profile.activityLevel}'),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Blood profile',
                          style: Theme.of(context).textTheme.titleLarge),
                      const SizedBox(height: 14),
                      Wrap(
                        spacing: 12,
                        runSpacing: 12,
                        children: [
                          _Metric(
                            icon: Icons.bloodtype,
                            label: 'Blood type',
                            value: profile.bloodDisplay,
                          ),
                          _Metric(
                            icon: Icons.monitor_weight_outlined,
                            label: 'BMI',
                            value: profile.bmi.toStringAsFixed(1),
                          ),
                          _Metric(
                            icon: Icons.volunteer_activism_outlined,
                            label: 'Donor',
                            value: profile.bloodDonor ? 'Yes' : 'No',
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
              const Card(
                child: Column(
                  children: [
                    ListTile(
                      leading: Icon(Icons.restaurant_menu),
                      title: Text('Nutrition'),
                      subtitle: Text(
                        'Evidence-aligned general guidance, not a blood-type diet.',
                      ),
                    ),
                    Divider(height: 1),
                    ListTile(
                      leading: Icon(Icons.clean_hands_outlined),
                      title: Text('Hygiene'),
                      subtitle: Text(
                        'Daily hand, oral, food and personal hygiene education.',
                      ),
                    ),
                    Divider(height: 1),
                    ListTile(
                      leading: Icon(Icons.science_outlined),
                      title: Text('Rh education'),
                      subtitle: Text(
                        'Learn why Rh status matters for transfusion and pregnancy.',
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              FilledButton.icon(
                onPressed: () => context.push(AppRoutes.report),
                icon: const Icon(Icons.description_outlined),
                label: const Text('GET REPORT'),
              ),
              const SizedBox(height: 12),
              OutlinedButton.icon(
                onPressed: () => context.push(AppRoutes.report),
                icon: const Icon(Icons.volume_up_outlined),
                label: const Text('LISTEN TO REPORT'),
              ),
              const SizedBox(height: 12),
              TextButton.icon(
                onPressed: () async {
                  await ref.read(profileProvider.notifier).clear();
                  if (context.mounted) context.go(AppRoutes.profile);
                },
                icon: const Icon(Icons.restart_alt),
                label: const Text('RESET PROFILE'),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _Metric extends StatelessWidget {
  const _Metric({
    required this.icon,
    required this.label,
    required this.value,
  });

  final IconData icon;
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 140,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon),
          const SizedBox(height: 8),
          Text(label),
          Text(
            value,
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.w800,
                ),
          ),
        ],
      ),
    );
  }
}

class _ErrorState extends StatelessWidget {
  const _ErrorState({
    required this.message,
    required this.onRetry,
    this.actionText = 'RETRY',
  });

  final String message;
  final VoidCallback onRetry;
  final String actionText;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.error_outline, size: 48),
            const SizedBox(height: 12),
            Text(message, textAlign: TextAlign.center),
            const SizedBox(height: 18),
            FilledButton(onPressed: onRetry, child: Text(actionText)),
          ],
        ),
      ),
    );
  }
}
