/// ------------------------------------------------------------
/// BloodWise+ AI Genesis
/// Founder: Papany Podol
/// Author (Legal Name): Jean Bertin Tonje – Mbombog Pharaoh Tonje
/// Copyright © 2026. All Rights Reserved.
/// Version: 0.1.0-beta.1-candidate
/// ------------------------------------------------------------


import 'package:flutter/material.dart';

class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('About')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Center(
            child: Image.asset(
              'assets/images/si_ngambi_logo.jpeg',
              height: 240,
              fit: BoxFit.contain,
            ),
          ),
          const SizedBox(height: 18),
          Text(
            'BloodWise+ AI Genesis',
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.w800,
                ),
          ),
          const SizedBox(height: 16),
          const Card(
            child: Padding(
              padding: EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Founder', style: TextStyle(fontWeight: FontWeight.bold)),
                  Text('Papany Podol'),
                  SizedBox(height: 14),
                  Text(
                    'Author (Legal Name)',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  Text('Jean Bertin Tonje – Mbombog Pharaoh Tonje'),
                  SizedBox(height: 14),
                  Text('Version', style: TextStyle(fontWeight: FontWeight.bold)),
                  Text('0.1.0-beta.1-candidate'),
                  SizedBox(height: 14),
                  Text(
                    'Educational disclaimer',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  Text(
                    'BloodWise+ provides general educational information and does not replace professional medical advice, diagnosis or treatment.',
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
