/// ------------------------------------------------------------
/// BloodWise+ AI Genesis
/// Founder: Papany Podol
/// Author (Legal Name): Jean Bertin Tonje – Mbombog Pharaoh Tonje
/// Copyright © 2026. All Rights Reserved.
/// Version: 0.1.0-beta.1-candidate
/// ------------------------------------------------------------


import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_tts/flutter_tts.dart';
import '../../core/providers/app_providers.dart';

class ReportScreen extends ConsumerStatefulWidget {
  const ReportScreen({super.key});

  @override
  ConsumerState<ReportScreen> createState() => _ReportScreenState();
}

class _ReportScreenState extends ConsumerState<ReportScreen> {
  final FlutterTts _tts = FlutterTts();
  bool _speaking = false;

  Future<void> _listen(String text, String language) async {
    if (_speaking) {
      await _tts.stop();
      if (mounted) setState(() => _speaking = false);
      return;
    }

    final locale = switch (language) {
      'French' => 'fr-FR',
      'Spanish' => 'es-ES',
      _ => 'en-US',
    };

    await _tts.setLanguage(locale);
    await _tts.setSpeechRate(0.45);
    _tts.setCompletionHandler(() {
      if (mounted) setState(() => _speaking = false);
    });

    setState(() => _speaking = true);
    await _tts.speak(text);
  }

  @override
  void dispose() {
    _tts.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final profileValue = ref.watch(profileProvider);
    final reportService = ref.watch(reportServiceProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Your Report')),
      body: profileValue.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (error, stackTrace) => Center(child: Text('$error')),
        data: (profile) {
          if (profile == null) {
            return const Center(child: Text('No profile is available.'));
          }

          final report = reportService.build(profile);
          return ListView(
            padding: const EdgeInsets.all(20),
            children: [
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: SelectableText(
                    report,
                    style: const TextStyle(height: 1.45),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              FilledButton.icon(
                onPressed: () => _listen(report, profile.preferredLanguage),
                icon: Icon(_speaking ? Icons.stop : Icons.volume_up),
                label: Text(_speaking ? 'STOP' : 'LISTEN'),
              ),
            ],
          );
        },
      ),
    );
  }
}
