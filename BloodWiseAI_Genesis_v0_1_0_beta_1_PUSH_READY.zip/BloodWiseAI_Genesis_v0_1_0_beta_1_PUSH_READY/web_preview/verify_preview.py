from pathlib import Path
import re
import subprocess
import sys

root = Path(__file__).resolve().parent
html = (root / "index.html").read_text(encoding="utf-8")
checks = {
    "one start button": html.count('id="startButton"') == 1,
    "explicit start handler": "$('#startButton').addEventListener('click'" in html,
    "profile save": "localStorage.setItem('bloodwise_profile_v1'" in html,
    "returning profile load": "loadProfile()" in html,
    "report screen": 'id="report"' in html,
    "manifest": (root / "manifest.webmanifest").exists(),
    "service worker": (root / "service-worker.js").exists(),
}
script = re.search(r"<script>([\s\S]*?)</script>", html)
if script:
    temp = root / ".syntax_check.js"
    temp.write_text(script.group(1), encoding="utf-8")
    try:
        result = subprocess.run(["node", "--check", str(temp)], capture_output=True)
        checks["JavaScript syntax"] = result.returncode == 0
    except FileNotFoundError:
        checks["JavaScript syntax"] = None
    finally:
        temp.unlink(missing_ok=True)

for name, result in checks.items():
    label = "PASS" if result is True else ("SKIP" if result is None else "FAIL")
    print(f"{label}: {name}")

sys.exit(1 if any(result is False for result in checks.values()) else 0)
