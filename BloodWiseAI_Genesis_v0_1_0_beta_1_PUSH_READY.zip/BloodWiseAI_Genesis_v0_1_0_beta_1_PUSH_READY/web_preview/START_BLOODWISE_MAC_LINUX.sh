#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
if command -v python3 >/dev/null 2>&1; then
  (sleep 1; python3 -m webbrowser http://localhost:8080 >/dev/null 2>&1 || true) &
  python3 -m http.server 8080
elif command -v python >/dev/null 2>&1; then
  (sleep 1; python -m webbrowser http://localhost:8080 >/dev/null 2>&1 || true) &
  python -m http.server 8080
else
  echo "Python 3 is required."
  exit 1
fi
