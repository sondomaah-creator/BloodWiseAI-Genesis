# Start BloodWise+ AI Genesis

## Windows

Double-click:

```text
START_BLOODWISE_WINDOWS.bat
```

The launcher opens the application at:

```text
http://localhost:8080
```

## macOS or Linux

Run:

```bash
./START_BLOODWISE_MAC_LINUX.sh
```

## Manual command

```bash
python3 -m http.server 8080
```

Then open `http://localhost:8080`.

## Install as an app

In Chrome, Edge, or another compatible browser, use **Install app** or **Add to Home Screen**.

## Verify the preview

```bash
python3 verify_preview.py
```
