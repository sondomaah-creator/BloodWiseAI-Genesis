# Next Step — Create the GitHub Repository

## Windows

Double-click:

```text
scripts/INIT_GIT_WINDOWS.bat
```

## macOS or Linux

Run:

```bash
./scripts/INIT_GIT_MAC_LINUX.sh
```

Then create a private GitHub repository named:

```text
BloodWiseAI-Genesis
```

Connect and push:

```bash
git remote add origin https://github.com/YOUR-USERNAME/BloodWiseAI-Genesis.git
git push -u origin main
```

After the push, open:

```text
GitHub → Actions → Build Android Release APK → Run workflow
```

Download the generated APK from the workflow's **Artifacts** section.
