# Contributing

1. Create a branch from `develop`.
2. Keep each change focused.
3. Run:
   ```bash
   dart format .
   flutter analyze
   flutter test
   ```
4. Update documentation and `CHANGELOG.md`.
5. Open a pull request using the provided template.

## Branch names

- `feature/<name>`
- `fix/<issue>`
- `docs/<name>`
- `release/<version>`

## Commit examples

- `feat(profile): persist complete user profile`
- `fix(startup): prevent duplicate navigation`
- `test(report): verify Rh-negative report text`
