# Push BloodWise+ AI Genesis to GitHub

## 1. Create the private repository

Create a private GitHub repository named:

```text
BloodWiseAI-Genesis
```

Do not initialize it with a README, license, or `.gitignore`.

## 2. Push with one command

### Windows

Double-click:

```text
scripts/PUSH_TO_GITHUB_WINDOWS.bat
```

### macOS or Linux

Run:

```bash
./scripts/PUSH_TO_GITHUB_MAC_LINUX.sh
```

When prompted, paste the repository URL, for example:

```text
https://github.com/YOUR-USERNAME/BloodWiseAI-Genesis.git
```

## 3. Build the APK

On GitHub:

```text
Actions → Build Android Release APK → Run workflow
```

After the workflow completes, download the APK from **Artifacts**.

## Authentication note

GitHub may open a browser for authentication. If command-line Git requests a
password, use a GitHub personal access token instead of your account password.
