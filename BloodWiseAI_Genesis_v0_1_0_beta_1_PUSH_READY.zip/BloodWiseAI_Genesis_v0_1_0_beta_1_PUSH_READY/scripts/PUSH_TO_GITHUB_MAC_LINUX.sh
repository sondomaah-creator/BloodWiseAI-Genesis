#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

if ! command -v git >/dev/null 2>&1; then
  echo "Git is not installed."
  exit 1
fi

if [ ! -d .git ]; then
  git init
  git branch -M main
fi

git add .
git commit -m "chore: prepare BloodWise Beta 1 candidate" || true

echo
read -r -p "Paste your private GitHub repository URL: " REPOURL
if [ -z "$REPOURL" ]; then
  echo "No repository URL entered."
  exit 1
fi

git remote remove origin 2>/dev/null || true
git remote add origin "$REPOURL"
git push -u origin main

echo
echo "Push completed."
echo "Open GitHub, then go to:"
echo "Actions > Build Android Release APK > Run workflow"
