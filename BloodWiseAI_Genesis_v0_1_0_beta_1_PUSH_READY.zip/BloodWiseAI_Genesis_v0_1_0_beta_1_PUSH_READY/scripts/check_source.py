from pathlib import Path
import re
import sys
import json

root = Path(__file__).resolve().parents[1]
dart_files = list((root / "lib").rglob("*.dart"))
checks = {}

checks["main.dart exists"] = (root / "lib/main.dart").exists()
checks["pubspec exists"] = (root / "pubspec.yaml").exists()
checks["logo exists"] = (root / "assets/images/si_ngambi_logo.jpeg").exists()

splash = (root / "lib/features/splash/splash_screen.dart").read_text(encoding="utf-8")
checks["one production start label"] = splash.count("START APPLICATION") == 1
checks["start handler exists"] = "Future<void> _start()" in splash

checks["relative imports resolve"] = True
for file in dart_files:
    text = file.read_text(encoding="utf-8")
    for match in re.finditer(r"import '(\.{1,2}/[^']+\.dart)';", text):
        target = (file.parent / match.group(1)).resolve()
        if not target.exists():
            checks["relative imports resolve"] = False

pubspec = (root / "pubspec.yaml").read_text(encoding="utf-8")
checks["logo declared in pubspec"] = "assets/images/si_ngambi_logo.jpeg" in pubspec
checks["Riverpod dependency declared"] = "flutter_riverpod:" in pubspec
checks["GoRouter dependency declared"] = "go_router:" in pubspec
checks["TTS dependency declared"] = "flutter_tts:" in pubspec

for name, passed in checks.items():
    print(f"{'PASS' if passed else 'FAIL'}: {name}")

sys.exit(1 if not all(checks.values()) else 0)
