@echo off
setlocal
cd /d "%~dp0\.."

where git >nul 2>nul
if errorlevel 1 (
  echo Git is not installed or not available in PATH.
  pause
  exit /b 1
)

if not exist .git (
  git init
  git branch -M main
)

git add .
git commit -m "chore: prepare BloodWise Beta 1 candidate" 2>nul

echo.
set /p REPOURL=Paste your private GitHub repository URL: 
if "%REPOURL%"=="" (
  echo No repository URL entered.
  pause
  exit /b 1
)

git remote remove origin 2>nul
git remote add origin "%REPOURL%"
git push -u origin main

if errorlevel 1 (
  echo.
  echo Push failed. Review the Git message above.
  pause
  exit /b 1
)

echo.
echo Push completed.
echo Open GitHub, then go to:
echo Actions ^> Build Android Release APK ^> Run workflow
pause
