$ErrorActionPreference = "Stop"
dart format .
flutter analyze
flutter test
