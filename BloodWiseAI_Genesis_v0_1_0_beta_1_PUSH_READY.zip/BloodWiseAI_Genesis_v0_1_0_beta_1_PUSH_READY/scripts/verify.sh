#!/usr/bin/env bash
set -euo pipefail
dart format .
flutter analyze
flutter test
