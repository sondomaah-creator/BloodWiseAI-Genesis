#!/usr/bin/env bash
set -euo pipefail
flutter create . --platforms=android,ios,web,windows,macos,linux
flutter pub get
dart format .
flutter analyze
flutter test
echo "BloodWise source checks completed."
