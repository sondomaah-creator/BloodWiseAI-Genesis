#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

if ! command -v git >/dev/null 2>&1; then
  echo "Git is not installed."
  exit 1
fi

if [ ! -d .git ]; then
  git init
  git branch -M main
fi

git add .
git commit -m "chore: initialize BloodWise Beta 1 candidate" || true

cat <<'EOF'

Repository initialized.

Next:
1. Create a private GitHub repository named BloodWiseAI-Genesis
2. Run:
   git remote add origin https://github.com/YOUR-USERNAME/BloodWiseAI-Genesis.git
   git push -u origin main
EOF
