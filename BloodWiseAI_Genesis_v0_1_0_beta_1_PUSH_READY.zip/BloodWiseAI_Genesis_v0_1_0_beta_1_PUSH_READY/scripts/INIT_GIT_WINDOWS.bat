@echo off
setlocal
cd /d "%~dp0\.."

where git >nul 2>nul
if errorlevel 1 (
  echo Git is not installed or not available in PATH.
  pause
  exit /b 1
)

if exist .git (
  echo This folder is already a Git repository.
) else (
  git init
  git branch -M main
)

git add .
git commit -m "chore: initialize BloodWise Beta 1 candidate"

echo.
echo Repository initialized.
echo Next:
echo   1. Create a private GitHub repository named BloodWiseAI-Genesis
echo   2. Run:
echo      git remote add origin https://github.com/YOUR-USERNAME/BloodWiseAI-Genesis.git
echo      git push -u origin main
pause
