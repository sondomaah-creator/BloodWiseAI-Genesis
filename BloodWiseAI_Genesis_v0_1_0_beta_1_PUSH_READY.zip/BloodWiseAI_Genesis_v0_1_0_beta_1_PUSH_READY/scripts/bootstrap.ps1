$ErrorActionPreference = "Stop"
flutter create . --platforms=android,ios,web,windows,macos,linux
flutter pub get
dart format .
flutter analyze
flutter test
Write-Host "BloodWise source checks completed."
