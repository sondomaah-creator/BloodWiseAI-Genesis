# Changelog

## 0.1.0-beta.1 Candidate — 2026-07-09

### Added
- Privacy policy.
- Beta release checklist.
- Known-issues register.
- Source consistency checker.
- Beta candidate release notes.

## 0.1.0-beta.1-candidate — 2026-07-09

### Added
- Git-ready repository metadata and ignore rules.
- All Rights Reserved license and security policy.
- Bug, feature and pull-request templates.
- CI workflow that produces a downloadable debug APK artifact.
- Tag/manual workflow that produces a release APK artifact.
- GitHub repository setup guide.
- Local Makefile and verification scripts.

## 0.1.0-beta.1-candidate — 2026-07-09

### Verified
- Complete browser startup, onboarding, dashboard, report, returning-user and reset workflow in headless Chromium.
- Single visible startup control and explicit event handler.
- JavaScript syntax.

## 0.1.0-beta.1-candidate — 2026-07-09

### Added
- One-click Windows preview launcher.
- One-click macOS/Linux preview launcher.
- Preview diagnostics script.
- HTTP launch instructions for reliable PWA initialization.
- Local server smoke test.

## 0.1.0-beta.1-candidate — 2026-07-09

### Added
- Installable PWA manifest and application icons.
- Offline service worker for the browser preview.
- Node JavaScript syntax verification.
- Static single-start and persistence verification report.

## 0.1.0-beta.1-candidate — 2026-07-09

### Added
- Fully integrated startup, profile, dashboard, report, voice and About flow.
- One explicit Start Application control.
- Complete profile JSON persistence with SharedPreferences.
- Manual/calendar date-of-birth entry.
- English, French and Spanish TTS locale selection.
- Unit and integration test scaffolding.
- Standalone offline browser preview.
- Updated legal author attribution.

### Removed
- Drift code generation dependency from the MVP baseline.
- Placeholder profile values.
- Duplicate initialization paths.
