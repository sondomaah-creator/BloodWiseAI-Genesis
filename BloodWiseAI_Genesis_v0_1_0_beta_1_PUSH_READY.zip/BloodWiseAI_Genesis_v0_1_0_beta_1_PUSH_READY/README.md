# BloodWise+ AI Genesis — v0.1.0-beta.1-candidate

A debuggable Flutter MVP for offline blood-group education, nutrition, hygiene, Rh information, profile storage, report generation, and text-to-speech.

## Attribution

- **Founder:** Papany Podol
- **Author (Legal Name):** Jean Bertin Tonje – Mbombog Pharaoh Tonje
- **Copyright:** © 2026. All Rights Reserved.

## Implemented

- Single `START APPLICATION` action
- Si Ngambi logo on startup
- Returning-user routing
- Smart Profile with manual or calendar DOB input
- ABO and Rh selection
- Local profile persistence
- Dashboard
- Educational report
- Device text-to-speech
- English, French and Spanish voice locale selection
- About screen and official attribution
- Unit and integration test scaffolding

## GitHub and automatic APK builds

See [`docs/GITHUB_SETUP.md`](docs/GITHUB_SETUP.md). The repository includes:

- pull-request verification
- analyzer and test execution
- debug APK artifact generation
- tag-triggered release APK artifact generation

## Build

This package contains source code. A Flutter SDK is required to create platform folders and compile executables.

```bash
flutter create . --platforms=android,ios,web,windows,macos,linux
flutter pub get
dart format .
flutter analyze
flutter test
flutter run
```

For Android release:

```bash
flutter build apk --release
```

Output:

```text
build/app/outputs/flutter-apk/app-release.apk
```

## One-click standalone preview

Inside `web_preview`:

- Windows: double-click `START_BLOODWISE_WINDOWS.bat`
- macOS/Linux: run `./START_BLOODWISE_MAC_LINUX.sh`

This serves the app at `http://localhost:8080`, enabling PWA installation and offline caching.

## Immediate browser preview

Open `web_preview/index.html`. It is a standalone offline demonstration, separate from the Flutter source.

## Medical responsibility

Blood type is important for transfusion matching and Rh-related care. Current mainstream evidence does not support prescribing a diet solely from ABO blood type. BloodWise+ presents general educational guidance and does not replace clinical care.

## Verification status

- Source assembled and internally cross-checked for imports and file references.
- Flutter compilation was **not available in this execution environment**.
- Run the commands above in a Flutter environment before calling this a verified release.
