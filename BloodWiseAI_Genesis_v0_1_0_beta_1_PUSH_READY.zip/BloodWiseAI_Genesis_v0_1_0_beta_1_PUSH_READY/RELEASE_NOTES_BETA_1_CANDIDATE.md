# BloodWise+ AI Genesis v0.1.0-beta.1 Candidate

## Included

- Si Ngambi branded startup screen
- One Start Application command
- Smart Profile form
- Local profile persistence
- Returning-user startup routing
- Personalized Dashboard
- Educational nutrition, hygiene, blood-group, and Rh content
- Educational report
- Text-to-speech
- About screen with official attribution
- Standalone installable PWA preview
- GitHub CI and APK artifact workflows
- Privacy policy, security policy, and release checklist

## Verification status

The JavaScript preview and source consistency checks pass in this environment.
Native Flutter compilation remains pending until GitHub Actions or a machine with
the Flutter SDK executes the included workflows.
